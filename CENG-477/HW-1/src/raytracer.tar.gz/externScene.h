#ifndef _EXTERNSCENE_H_
#define _EXTERNSCENE_H_

#include "parser.h"

extern parser::Scene created_scene;

#endif